# AI Base Hunter — Android Studio prototype

An Android companion prototype for Minecraft Bedrock / DonutSMP.

## Current implemented features
- Pick and preview a Minecraft screenshot from device storage.
- Mark a screenshot as a candidate for manual review.
- Save, delete, and copy candidate coordinates.
- Local storage for waypoint notes.

## Not implemented
- AI/computer-vision base recognition.
- Automatic movement or autonomous gameplay.
- ESP, live block reading, or direct DonutSMP/server inspection.

This app cannot access hidden server-side data. Open the folder in Android Studio and build/run it on a device.
