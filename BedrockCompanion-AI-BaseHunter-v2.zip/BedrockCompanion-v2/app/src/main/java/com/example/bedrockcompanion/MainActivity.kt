package com.example.bedrockcompanion

import android.app.Activity
import android.os.Bundle
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.net.Uri
import android.content.Intent
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("basehunter", MODE_PRIVATE) }
    private lateinit var list: LinearLayout
    private lateinit var nameInput: EditText
    private lateinit var xInput: EditText
    private lateinit var yInput: EditText
    private lateinit var zInput: EditText
    private lateinit var screenshotPreview: ImageView
    private lateinit var scanStatus: TextView
    private var screenshotUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 20, 20, 20) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(TextView(this).apply { text = "AI Base Hunter • Bedrock"; textSize = 25f; setTypeface(null, Typeface.BOLD) })
        content.addView(TextView(this).apply { text = "Companion prototype for Minecraft Bedrock / DonutSMP. It does not inject into Minecraft or read hidden server data."; textSize = 14f; setPadding(0, 8, 0, 14) })
        content.addView(TextView(this).apply { text = "1. Screenshot scanner"; textSize = 19f; setTypeface(null, Typeface.BOLD) })
        content.addView(Button(this).apply { text = "Choose Minecraft screenshot"; setOnClickListener { chooseScreenshot() } })
        screenshotPreview = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER; contentDescription = "Selected Minecraft screenshot" }
        content.addView(screenshotPreview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 500))
        scanStatus = TextView(this).apply { text = "No screenshot selected. Select one to inspect it."; textSize = 14f; setPadding(0, 6, 0, 12) }
        content.addView(scanStatus)
        content.addView(Button(this).apply { text = "Mark screenshot as base candidate"; setOnClickListener {
            if (screenshotUri == null) Toast.makeText(this@MainActivity, "Choose a screenshot first", Toast.LENGTH_SHORT).show()
            else { prefs.edit().putString("lastCandidate", screenshotUri.toString()).apply(); scanStatus.text = "Candidate saved for manual review. This prototype does not yet recognize bases automatically."; Toast.makeText(this@MainActivity, "Candidate marked", Toast.LENGTH_SHORT).show() }
        } })
        content.addView(TextView(this).apply { text = "2. Save candidate coordinates"; textSize = 19f; setTypeface(null, Typeface.BOLD); setPadding(0, 18, 0, 4) })
        nameInput = field("Candidate name / notes")
        xInput = field("X coordinate"); yInput = field("Y coordinate"); zInput = field("Z coordinate")
        content.addView(nameInput); content.addView(xInput); content.addView(yInput); content.addView(zInput)
        content.addView(Button(this).apply { text = "Save candidate waypoint"; setOnClickListener { saveWaypoint() } })
        content.addView(Button(this).apply { text = "Copy all coordinates"; setOnClickListener { copyAll() } })
        content.addView(TextView(this).apply { text = "Saved candidates"; textSize = 20f; setTypeface(null, Typeface.BOLD); setPadding(0, 18, 0, 8) })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
        renderWaypoints()
    }

    private fun field(hintText: String) = EditText(this).apply { hint = hintText; singleLine = true; inputType = android.text.InputType.TYPE_CLASS_TEXT }

    private fun chooseScreenshot() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }
        startActivityForResult(intent, 41)
    }

    @Deprecated("Using compatible document picker for broad Android support")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            try {
                contentResolver.openInputStream(uri).use { stream ->
                    val bitmap = BitmapFactory.decodeStream(stream)
                    if (bitmap != null) {
                        screenshotUri = uri
                        screenshotPreview.setImageBitmap(bitmap)
                        scanStatus.text = "Screenshot loaded. Visual recognition is not implemented yet; review the image yourself and mark it if it looks like a candidate."
                    } else Toast.makeText(this, "Could not open image", Toast.LENGTH_SHORT).show()
                }
            } catch (_: Exception) { Toast.makeText(this, "Could not open image", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun saveWaypoint() {
        val name = nameInput.text.toString().trim().ifBlank { "Base candidate" }
        val x = xInput.text.toString().trim(); val y = yInput.text.toString().trim(); val z = zInput.text.toString().trim()
        if (x.toIntOrNull() == null || y.toIntOrNull() == null || z.toIntOrNull() == null) {
            Toast.makeText(this, "Enter valid X, Y, and Z coordinates", Toast.LENGTH_SHORT).show(); return
        }
        val arr = load(); arr.put(JSONObject().put("name", name).put("x", x).put("y", y).put("z", z))
        prefs.edit().putString("data", arr.toString()).apply()
        nameInput.text.clear(); xInput.text.clear(); yInput.text.clear(); zInput.text.clear()
        renderWaypoints(); Toast.makeText(this, "Candidate waypoint saved", Toast.LENGTH_SHORT).show()
    }

    private fun load(): JSONArray = try { JSONArray(prefs.getString("data", "[]")) } catch (_: Exception) { JSONArray() }

    private fun renderWaypoints() {
        list.removeAllViews(); val arr = load()
        if (arr.length() == 0) list.addView(TextView(this).apply { text = "No candidates saved yet." })
        for (i in arr.length() - 1 downTo 0) {
            val item = arr.getJSONObject(i)
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(10, 10, 10, 10) }
            row.addView(TextView(this).apply { text = item.optString("name"); textSize = 17f; setTypeface(null, Typeface.BOLD) })
            row.addView(TextView(this).apply { text = "X ${item.optString("x")}   Y ${item.optString("y")}   Z ${item.optString("z")}" })
            row.addView(Button(this).apply { text = "Delete"; setOnClickListener {
                val updated = JSONArray(); for (j in 0 until arr.length()) if (j != i) updated.put(arr.get(j))
                prefs.edit().putString("data", updated.toString()).apply(); renderWaypoints()
            } })
            list.addView(row); list.addView(android.view.View(this).apply { setBackgroundColor(0xFFCCCCCC.toInt()) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
        }
    }

    private fun copyAll() {
        val arr = load()
        val text = (0 until arr.length()).joinToString("\n") { i -> val o = arr.getJSONObject(i); "${o.optString("name")}: X${o.optString("x")} Y${o.optString("y")} Z${o.optString("z")}" }
        if (text.isBlank()) { Toast.makeText(this, "No candidates to copy", Toast.LENGTH_SHORT).show(); return }
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Base candidates", text))
        Toast.makeText(this, "Coordinates copied", Toast.LENGTH_SHORT).show()
    }
}
